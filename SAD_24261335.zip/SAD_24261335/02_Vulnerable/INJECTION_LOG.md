# Injection Log — 02_Vulnerable

Shreesh Kallihal (24261335)
Secure Application Development

This file covers the five vulnerabilities I deliberately injected into 02_Vulnerable. For each one I've listed where it sits in the code, how to exploit it, and which figure in the report captures the evidence. I went for bugs that you actually come across in real Java codebases rather than textbook examples that nobody writes anymore.

## Summary table

| ID    | File:Line                          | Description                                          | Exploit steps                                                                                                  | Evidence  |
|-------|------------------------------------|------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|-----------|
| V-001 | sad/dao/BookshopDAO.java:156       | SQL Injection in searchBooks() via string concat     | Log in, open Search, paste `' UNION SELECT id, NULL, username, password, NULL, NULL, NULL, NULL, NULL, NULL, NULL FROM users#` | Figure 2  |
| V-002 | sad/dao/BookshopDAO.java:284       | No duplicate check in requestLoan()                  | Log in as a member, request a loan for a book, then click the request button again on the same book            | Figure 3  |
| V-003 | sad/dao/BookshopDAO.java:353       | No ownership check in requestExchange()              | Log in, pick any book from the catalogue, submit it for exchange even though you never borrowed it             | Figure 4  |
| V-004 | sad/dao/BookshopDAO.java:433       | No role or embargo filter on restricted collection   | Log in as Customer, open Restricted Collection — future-dated research is listed even though you're not a researcher | Figure 5  |
| V-005 | sad/gui/LoginFrame.java:99         | Username enumeration in login error                  | Try a random username, the error echoes the username and confirms whether the account exists                   | Figure A1 |

---

## V-001 SQL Injection in Book Search

The search code at BookshopDAO.java line 156 stitches the keyword straight into the SQL using string concat, so any input with a quote in it breaks out of the LIKE pattern and runs whatever you put after it.

```java
String sql = "SELECT * FROM books WHERE title LIKE '%" + keyword + "%' "
           + "OR author LIKE '%" + keyword + "%' "
           + "OR isbn LIKE '%" + keyword + "%'";
```

Why this happens in real code: devs often skip PreparedStatement for search because they treat it as a read-only feature and assume the input is harmless. That's exactly where this class of bug lives.

Payload I used in testing (11 columns because `SELECT *` on the books table expands to 11):
```
' UNION SELECT id, NULL, username, password, NULL, NULL, NULL, NULL, NULL, NULL, NULL FROM users#
```

Position 3 lands on the `title` column and position 4 lands on `author`, so the username renders under Title and the password hash renders under Author in the results grid. That's a full credential dump straight out of the search box.

Mapped to OWASP A03:2025 Injection and CWE-89.

---

## V-002 Duplicate Loan

The requestLoan() method at line 284 inserts a new loan row without first checking whether the same user already has a pending or approved loan for the same book. That means the same copy can be borrowed twice by the same person and the stock counter drifts further below reality with each duplicate.

```java
String sql = "INSERT INTO loans (user_id, book_id, loan_date, return_date, status) "
           + "VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'PENDING')";
```

No SELECT COUNT(*) runs before the INSERT, and the schema has no unique constraint on (user_id, book_id) for active loans, so the database just accepts the repeat.

Why this happens in real code: devs assume the UI button can't be clicked twice, so they don't guard the server side. But anyone bypassing the GUI or double-clicking fast enough gets a duplicate through. Mapped to OWASP A06:2025 Insecure Design and CWE-840.

---

## V-003 Exchange Without Ownership

The requestExchange() at line 353 takes a book_id as input and writes an exchange row without ever checking whether the user actually has an approved loan for that book. You can submit an exchange for any book in the catalogue, even one you've never seen before.

```java
String sql = "INSERT INTO exchange_requests (user_id, book_id, reason, status) "
           + "VALUES (?, ?, ?, 'PENDING')";
```

There's no SELECT on the loans table before the insert. The DAO just trusts the book_id passed in.

Why this happens in real code: the DAO layer was written to be dumb and fast, and ownership was assumed to be enforced by whichever panel called the method. But once a method is callable from anywhere, that assumption dies. Mapped to OWASP A01:2025 Broken Access Control and CWE-863.

---

## V-004 Restricted Collection Leak

The getRestrictedBooks() method at line 433 has no role parameter and no embargo_date filter, so any logged in user — including a regular Customer — can load the entire restricted collection and see research that is still inside its embargo window.

```java
String sql = "SELECT * FROM restricted_books ORDER BY title";
```

The table has an embargo_date column but the query ignores it, and nothing in the DAO rejects the call when the caller isn't a researcher.

Why this happens in real code: the dev relied on the menu hiding the Restricted button from non-researchers and thought that was enough. It never is — once the DAO method exists, anything with a DAO handle can call it. Mapped to OWASP A01:2025 Broken Access Control and CWE-862.

---

## V-005 Username Enumeration

The login error dialog at LoginFrame.java line 99 drops the attempted username straight into the message box. An attacker can fire a list of usernames at the form and tell from the error text which accounts actually exist.

```java
JOptionPane.showMessageDialog(this,
    "Login failed for user '" + username + "'. No account matched.",
    "Login Failed", JOptionPane.ERROR_MESSAGE);
```

A safe error message just says "Invalid username or password" with no echo and doesn't differentiate between wrong username and wrong password.

Why this happens in real code: devs add the username to the message because they think it's helpful feedback, but that one small detail is exactly what makes username enumeration and targeted brute force so much faster. Mapped to OWASP A09:2025 Security Logging and Monitoring Failures and CWE-209.

---

## OWASP 2025 and CWE mapping

| ID    | OWASP 2025                                           | CWE     |
|-------|------------------------------------------------------|---------|
| V-001 | A03:2025 Injection                                   | CWE-89  |
| V-002 | A06:2025 Insecure Design                             | CWE-840 |
| V-003 | A01:2025 Broken Access Control                       | CWE-863 |
| V-004 | A01:2025 Broken Access Control                       | CWE-862 |
| V-005 | A09:2025 Security Logging and Monitoring Failures    | CWE-209 |
