package sad.util;

/**  @author shreesh */

// I got tired of scattering the same checks across every GUI panel,
// so this class collects all the input validation in one place.
// If a check needs to change later, there is one spot to fix.

import java.util.regex.Pattern;

public class InputValidator {

    // email pattern - not perfect, but catches the obvious garbage
    private static final Pattern EMAIL_RE =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    // usernames: letters, digits, underscores, 3-50 chars
    private static final Pattern USERNAME_RE =
            Pattern.compile("^[A-Za-z0-9_]{3,50}$");

    private InputValidator() {} // not meant to be instantiated

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_RE.matcher(email.trim()).matches();
    }

    public static boolean isValidUsername(String username) {
        return username != null && USERNAME_RE.matcher(username.trim()).matches();
    }

    // Password rules: 8+ chars, at least one upper, one lower, one digit.
    // Nothing crazy, but way better than accepting "1".
    public static boolean isStrongPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper = false, hasLower = false, hasDigit = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isLowerCase(c)) hasLower = true;
            else if (Character.isDigit(c)) hasDigit = true;
        }
        return hasUpper && hasLower && hasDigit;
    }

    // for book stock, price, year etc - just a range check
    public static boolean isInRange(int value, int min, int max) {
        return value >= min && value <= max;
    }

    // quick trim + empty check
    public static boolean isNonEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    // max-length guard so people can't dump 10,000 chars into a search box
    public static boolean isWithinLength(String s, int maxLen) {
        return s != null && s.length() <= maxLen;
    }
}
