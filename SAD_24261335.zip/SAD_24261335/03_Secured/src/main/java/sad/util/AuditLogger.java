package sad.util;

/**  @author shreesh */

// Writes to the audit_log table in the database.
// The original app had an audit log tab in the admin panel but it was
// all fake hardcoded data. This actually records what happens.

import sad.db.DBConnection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AuditLogger {

    private static final Logger LOG = Logger.getLogger(AuditLogger.class.getName());

    private AuditLogger() {}

    public static void log(int userId, String action, String details) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "INSERT INTO audit_log (user_id, action, ip_address, details) VALUES (?, ?, ?, ?)");
            stmt.setInt(1, userId);
            stmt.setString(2, action);
            stmt.setString(3, "127.0.0.1"); // desktop app, always local
            stmt.setString(4, details);
            stmt.executeUpdate();
        } catch (SQLException e) {
            // don't let audit failures crash the main operation
            LOG.log(Level.WARNING, "Could not write audit log entry", e);
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }
}
