package sad.gui;

/**  @author shreesh */

// Secured login frame. Changes from the original:
// - brute force protection (locks out after 5 failed tries for 30 seconds)
// - password char[] is cleared from memory after use
// - error messages are generic (no stack traces, no system info)
// - guest fallback removed (if the DB guest is missing, you don't get in)

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import sad.dao.BookshopDAO;
import sad.model.User;
import sad.util.AuditLogger;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton guestButton;
    private BookshopDAO dao;

    // brute force tracking
    private int failedAttempts = 0;
    private long lockoutUntil = 0;
    private static final int MAX_ATTEMPTS = 5;
    private static final long LOCKOUT_MS = 30_000; // 30 seconds

    public LoginFrame() {
        dao = new BookshopDAO();
        initComponents();
    }

    private void initComponents() {
        setTitle("Bookshop Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Bookshop Management System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));

        formPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        formPanel.add(usernameField);

        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);

        formPanel.add(new JLabel(""));
        JPanel buttonPanel = new JPanel(new FlowLayout());
        loginButton = new JButton("Login");
        guestButton = new JButton("Continue as Guest");
        buttonPanel.add(loginButton);
        buttonPanel.add(guestButton);
        formPanel.add(buttonPanel);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        JLabel statusLabel = new JLabel("Enter credentials or continue as guest", SwingConstants.CENTER);
        statusLabel.setForeground(Color.GRAY);
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        add(mainPanel);

        loginButton.addActionListener(e -> performLogin());
        guestButton.addActionListener(e -> loginAsGuest());
        usernameField.addActionListener(e -> performLogin());
        passwordField.addActionListener(e -> performLogin());
    }

    // Fix for V-005: error messages are now generic. No stack traces,
    // no database URLs, no Java versions. Also added lockout after
    // too many failed attempts.
    private void performLogin() {
        // check if we're in lockout
        if (System.currentTimeMillis() < lockoutUntil) {
            long secsLeft = (lockoutUntil - System.currentTimeMillis()) / 1000;
            JOptionPane.showMessageDialog(this,
                "Too many failed attempts. Try again in " + secsLeft + " seconds.",
                "Account Locked",
                JOptionPane.WARNING_MESSAGE);
            return;
        }

        String username = usernameField.getText().trim();
        char[] passwordChars = passwordField.getPassword();
        String password = new String(passwordChars);

        // zero out the char array right away
        Arrays.fill(passwordChars, '\0');

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter both username and password",
                "Login Error",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            User user = dao.login(username, password);
            if (user != null) {
                failedAttempts = 0; // reset on success
                JOptionPane.showMessageDialog(this,
                    "Welcome, " + user.getFullName() + "!",
                    "Login Successful",
                    JOptionPane.INFORMATION_MESSAGE);
                openMainFrame(user);
            } else {
                failedAttempts++;
                if (failedAttempts >= MAX_ATTEMPTS) {
                    lockoutUntil = System.currentTimeMillis() + LOCKOUT_MS;
                    JOptionPane.showMessageDialog(this,
                        "Too many failed attempts. Locked for 30 seconds.",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
                } else {
                    // generic message - doesn't say if user exists or not
                    JOptionPane.showMessageDialog(this,
                        "Invalid credentials. Attempt " + failedAttempts + " of " + MAX_ATTEMPTS + ".",
                        "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            // log the real error server-side, show nothing useful to the user
            java.util.logging.Logger.getLogger(LoginFrame.class.getName())
                .log(java.util.logging.Level.SEVERE, "Login error", ex);
            JOptionPane.showMessageDialog(this,
                "A system error occurred. Please try again later.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    // Fixed: no more fallback guest. If the guest account doesn't exist
    // in the DB, you just don't get in. No more creating fake user objects.
    private void loginAsGuest() {
        try {
            User guest = dao.login("guest", "guest123");
            if (guest != null) {
                openMainFrame(guest);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Guest access is not available.",
                    "Login Failed",
                    JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(LoginFrame.class.getName())
                .log(java.util.logging.Level.SEVERE, "Guest login error", ex);
            JOptionPane.showMessageDialog(this,
                "A system error occurred. Please try again later.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void openMainFrame(User user) {
        MainFrame mainFrame = new MainFrame(user);
        mainFrame.setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                // not critical - just a look-and-feel issue
            }
            new LoginFrame().setVisible(true);
        });
    }
}
