package sad.gui;

/**  @author shreesh */

// routes the user to the right panel based on their role.
// the role comes from the database, not from the user object's setter,
// so it can't be tampered with client-side (the user object is populated
// by the DAO's login method, which reads the role from the DB row).

import javax.swing.*;
import sad.model.User;

public class MainFrame extends JFrame {

    public MainFrame(User user) {
        setTitle("Bookshop - " + user.getRole());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        String role = user.getRole();
        if (role == null) {
            JOptionPane.showMessageDialog(this, "No role assigned. Access denied.");
            dispose();
            return;
        }

        switch (role) {
            case "ADMIN":
                add(new AdminPanel(user));
                break;
            case "LIBRARIAN":
                add(new LibrarianPanel(user));
                break;
            case "RESEARCHER":
                add(new ResearcherPanel(user));
                break;
            case "CUSTOMER":
                add(new CustomerPanel(user));
                break;
            case "GUEST":
                add(new GuestPanel(user));
                break;
            default:
                JOptionPane.showMessageDialog(this,
                    "Unrecognised role: " + role + ". Access denied.");
                dispose();
        }
    }
}
