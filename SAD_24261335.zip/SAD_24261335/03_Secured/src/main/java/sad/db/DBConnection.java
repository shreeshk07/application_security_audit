package sad.db;

/**  @author shreesh */

// Fixed: credentials are now pulled from a .properties file instead of being
// baked into the source. That way they stay out of version control and can
// be swapped per environment without recompiling.

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection {

    private static final Logger LOG = Logger.getLogger(DBConnection.class.getName());

    // loaded once when the class is first touched
    private static String url;
    private static String user;
    private static String pass;

    static {
        try (InputStream in = DBConnection.class.getClassLoader()
                .getResourceAsStream("db.properties")) {
            if (in != null) {
                Properties props = new Properties();
                props.load(in);
                url  = props.getProperty("db.url");
                user = props.getProperty("db.user");
                pass = props.getProperty("db.password");
            } else {
                // fallback so the app still runs if the file is missing
                LOG.warning("db.properties not found on classpath - using defaults");
                url  = "jdbc:mysql://localhost:3306/bookshop?useSSL=true&serverTimezone=UTC";
                user = "root";
                pass = "password";
            }
        } catch (IOException e) {
            LOG.log(Level.SEVERE, "Could not read db.properties", e);
            // fall back to something that at least lets us start up
            url  = "jdbc:mysql://localhost:3306/bookshop?useSSL=true&serverTimezone=UTC";
            user = "root";
            pass = "password";
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            LOG.log(Level.SEVERE, "MySQL driver not on classpath", e);
        }
        return DriverManager.getConnection(url, user, pass);
    }

    // Fixed: exceptions are logged now instead of silently swallowed
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        if (rs != null) {
            try { rs.close(); } catch (SQLException e) {
                LOG.log(Level.WARNING, "Failed to close ResultSet", e);
            }
        }
        if (stmt != null) {
            try { stmt.close(); } catch (SQLException e) {
                LOG.log(Level.WARNING, "Failed to close Statement", e);
            }
        }
        if (conn != null) {
            try { conn.close(); } catch (SQLException e) {
                LOG.log(Level.WARNING, "Failed to close Connection", e);
            }
        }
    }
}
