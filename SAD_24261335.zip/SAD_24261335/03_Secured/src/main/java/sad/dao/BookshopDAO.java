package sad.dao;

/**  @author shreesh */

// Secured DAO. Every method that hits the database runs its own role
// and input check now instead of trusting whatever the GUI sends down.
// Passwords are BCrypt hashes (cost 12) and the search query is
// parameterised again so V-001 can't come back through the search box.

import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.mindrot.jbcrypt.BCrypt;
import sad.db.DBConnection;
import sad.model.Book;
import sad.model.Exchange;
import sad.model.Loan;
import sad.model.Order;
import sad.model.User;
import sad.util.AuditLogger;

public class BookshopDAO {

    private static final Logger LOG = Logger.getLogger(BookshopDAO.class.getName());

    // ==================== AUTHENTICATION ====================

    // Fixed: passwords are now hashed with BCrypt. The login method hashes
    // the incoming password and compares it to the stored hash instead of
    // doing a plaintext comparison in SQL.
    public User login(String username, String password) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM users WHERE username = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password");
                // BCrypt.checkpw handles the salt internally
                if (BCrypt.checkpw(password, storedHash)) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    // not storing the password hash on the user object
                    user.setFullName(rs.getString("full_name"));
                    user.setEmail(rs.getString("email"));
                    user.setRole(rs.getString("role"));
                    user.setCollegeId(rs.getInt("college_id"));
                    AuditLogger.log(user.getId(), "LOGIN_SUCCESS",
                            "User " + username + " logged in");
                    return user;
                }
            }
            // log failed attempts (but do not reveal whether the username exists)
            AuditLogger.log(0, "LOGIN_FAILED",
                    "Failed login attempt for input: " + username);
            return null;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // ==================== USERS ====================

    // Fixed: only returns user list if caller is ADMIN.
    // Also no longer returns the password column at all.
    public List<User> getAllUsers(String callerRole) throws SQLException {
        if (!"ADMIN".equals(callerRole)) {
            throw new SecurityException("Only admins can list all users");
        }

        List<User> users = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "SELECT id, username, full_name, email, role, college_id FROM users ORDER BY id");
            rs = stmt.executeQuery();

            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setFullName(rs.getString("full_name"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                user.setCollegeId(rs.getInt("college_id"));
                users.add(user);
            }
            return users;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // Fixed: hashes password with BCrypt before inserting.
    // The plaintext password never reaches the database.
    public boolean addUser(User user) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "INSERT INTO users (username, password, full_name, email, role, college_id) "
                       + "VALUES (?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, user.getUsername());
            // hash the password - 12 rounds is a reasonable cost factor
            stmt.setString(2, BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(12)));
            stmt.setString(3, user.getFullName());
            stmt.setString(4, user.getEmail());
            stmt.setString(5, user.getRole());
            stmt.setInt(6, user.getCollegeId());
            boolean result = stmt.executeUpdate() > 0;
            if (result) {
                AuditLogger.log(0, "USER_CREATED",
                    "New user: " + user.getUsername() + " role: " + user.getRole());
            }
            return result;
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }

    // Fixed: only ADMIN can delete, and you can't delete yourself.
    public boolean deleteUser(int userId, int callerId, String callerRole) throws SQLException {
        if (!"ADMIN".equals(callerRole)) {
            throw new SecurityException("Only admins can delete users");
        }
        if (userId == callerId) {
            throw new IllegalArgumentException("You cannot delete your own account");
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement("DELETE FROM users WHERE id = ?");
            stmt.setInt(1, userId);
            boolean result = stmt.executeUpdate() > 0;
            if (result) {
                AuditLogger.log(callerId, "USER_DELETED",
                    "Deleted user ID " + userId);
            }
            return result;
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }

    // ==================== BOOKS ====================

    public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM books ORDER BY title");
            rs = stmt.executeQuery();

            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("id"));
                book.setIsbn(rs.getString("isbn"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setPublisher(rs.getString("publisher"));
                book.setYear(rs.getInt("year"));
                book.setPrice(rs.getBigDecimal("price"));
                book.setStock(rs.getInt("stock"));
                book.setCollectionId(rs.getInt("collection_id"));
                book.setEmbargoDate(rs.getString("embargo_date"));
                books.add(book);
            }
            return books;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // Fix for V-001: back to PreparedStatement. The vulnerable version
    // concatenated the keyword straight into SQL. This uses bind variables
    // so the user's input can never break out of the LIKE pattern.
    public List<Book> searchBooks(String keyword) throws SQLException {
        List<Book> books = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?";
            stmt = conn.prepareStatement(sql);
            String pattern = "%" + keyword + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            stmt.setString(3, pattern);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setStock(rs.getInt("stock"));
                books.add(book);
            }
            return books;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    public boolean addBook(Book book) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "INSERT INTO books (isbn, title, author, publisher, year, price, stock, collection_id) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, book.getIsbn());
            stmt.setString(2, book.getTitle());
            stmt.setString(3, book.getAuthor());
            stmt.setString(4, book.getPublisher());
            stmt.setInt(5, book.getYear());
            stmt.setBigDecimal(6, book.getPrice());
            stmt.setInt(7, book.getStock());
            stmt.setInt(8, book.getCollectionId());
            return stmt.executeUpdate() > 0;
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }

    // Fixed: stock value must be >= 0
    public boolean updateBookStock(int bookId, int newStock) throws SQLException {
        if (newStock < 0) {
            throw new IllegalArgumentException("Stock cannot be negative");
        }
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement("UPDATE books SET stock = ? WHERE id = ?");
            stmt.setInt(1, newStock);
            stmt.setInt(2, bookId);
            return stmt.executeUpdate() > 0;
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }

    // ==================== LOANS ====================

    public List<Loan> getAllLoans(String callerRole) throws SQLException {
        if (!"LIBRARIAN".equals(callerRole) && !"ADMIN".equals(callerRole)) {
            throw new SecurityException("Only librarians or admins can view all loans");
        }

        List<Loan> loans = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "SELECT l.*, b.title as book_title, u.username as user_name " +
                "FROM loans l " +
                "LEFT JOIN books b ON l.book_id = b.id " +
                "LEFT JOIN users u ON l.user_id = u.id " +
                "ORDER BY l.loan_date DESC");
            rs = stmt.executeQuery();

            while (rs.next()) {
                Loan loan = new Loan();
                loan.setId(rs.getInt("id"));
                loan.setUserId(rs.getInt("user_id"));
                loan.setBookId(rs.getInt("book_id"));
                loan.setLoanType(rs.getString("loan_type"));
                loan.setLoanDate(rs.getDate("loan_date"));
                loan.setDueDate(rs.getDate("due_date"));
                loan.setReturnDate(rs.getDate("return_date"));
                loan.setApprovedBy(rs.getInt("approved_by"));
                loan.setStatus(rs.getString("status"));
                loan.setBookTitle(rs.getString("book_title"));
                loan.setUserName(rs.getString("user_name"));
                loans.add(loan);
            }
            return loans;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    public List<Loan> getUserLoans(int userId) throws SQLException {
        List<Loan> loans = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "SELECT l.*, b.title as book_title FROM loans l " +
                "LEFT JOIN books b ON l.book_id = b.id " +
                "WHERE l.user_id = ? ORDER BY l.loan_date DESC");
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Loan loan = new Loan();
                loan.setId(rs.getInt("id"));
                loan.setBookId(rs.getInt("book_id"));
                loan.setLoanType(rs.getString("loan_type"));
                loan.setLoanDate(rs.getDate("loan_date"));
                loan.setDueDate(rs.getDate("due_date"));
                loan.setReturnDate(rs.getDate("return_date"));
                loan.setStatus(rs.getString("status"));
                loan.setBookTitle(rs.getString("book_title"));
                loans.add(loan);
            }
            return loans;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // Fix for V-002: checks stock is available AND checks the user doesn't
    // already have a pending/active loan on this same book.
    // Also uses a proper parameterised interval instead of string concat.
    public boolean requestLoan(int userId, int bookId, String loanType) throws SQLException {
        Connection conn = null;
        PreparedStatement checkStock = null;
        PreparedStatement checkDup = null;
        PreparedStatement insertLoan = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // check the book actually has copies available
            checkStock = conn.prepareStatement("SELECT stock FROM books WHERE id = ?");
            checkStock.setInt(1, bookId);
            rs = checkStock.executeQuery();
            if (!rs.next() || rs.getInt("stock") <= 0) {
                return false; // book does not exist or is out of stock
            }
            rs.close();

            // check the user doesn't already have an active or pending loan on this book
            checkDup = conn.prepareStatement(
                "SELECT COUNT(*) FROM loans WHERE user_id = ? AND book_id = ? AND status IN ('PENDING','APPROVED')");
            checkDup.setInt(1, userId);
            checkDup.setInt(2, bookId);
            rs = checkDup.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return false; // already has a loan on this book
            }

            // figure out how many days based on loan type
            int days = "SHORT_TERM".equals(loanType) ? 14 : 90;
            String sql = "INSERT INTO loans (user_id, book_id, loan_type, loan_date, due_date, status) "
                       + "VALUES (?, ?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL ? DAY), 'PENDING')";
            insertLoan = conn.prepareStatement(sql);
            insertLoan.setInt(1, userId);
            insertLoan.setInt(2, bookId);
            insertLoan.setString(3, loanType);
            insertLoan.setInt(4, days);
            boolean ok = insertLoan.executeUpdate() > 0;
            if (ok) {
                AuditLogger.log(userId, "LOAN_REQUESTED",
                    "Loan requested for book " + bookId + " type " + loanType);
            }
            return ok;
        } finally {
            DBConnection.close(null, checkStock, null);
            DBConnection.close(null, checkDup, rs);
            DBConnection.close(conn, insertLoan, null);
        }
    }

    // Fixed: only librarian or admin can approve, and they can't approve
    // their own loan requests.
    public boolean approveLoan(int loanId, int approverId, String approverRole) throws SQLException {
        if (!"LIBRARIAN".equals(approverRole) && !"ADMIN".equals(approverRole)) {
            throw new SecurityException("Only librarians or admins can approve loans");
        }

        Connection conn = null;
        PreparedStatement check = null;
        PreparedStatement update = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // make sure the approver is not approving their own loan
            check = conn.prepareStatement("SELECT user_id FROM loans WHERE id = ?");
            check.setInt(1, loanId);
            rs = check.executeQuery();
            if (rs.next() && rs.getInt("user_id") == approverId) {
                throw new SecurityException("Cannot approve your own loan");
            }

            update = conn.prepareStatement(
                "UPDATE loans SET approved_by = ?, status = 'APPROVED' WHERE id = ? AND status = 'PENDING'");
            update.setInt(1, approverId);
            update.setInt(2, loanId);
            boolean ok = update.executeUpdate() > 0;
            if (ok) {
                AuditLogger.log(approverId, "LOAN_APPROVED", "Approved loan " + loanId);
            }
            return ok;
        } finally {
            DBConnection.close(null, check, rs);
            DBConnection.close(conn, update, null);
        }
    }

    // ==================== EXCHANGES ====================

    public List<Exchange> getAllExchanges(String callerRole) throws SQLException {
        if (!"LIBRARIAN".equals(callerRole) && !"ADMIN".equals(callerRole)) {
            throw new SecurityException("Only librarians or admins can view all exchanges");
        }

        List<Exchange> exchanges = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM exchanges ORDER BY request_date DESC");
            rs = stmt.executeQuery();

            while (rs.next()) {
                Exchange exchange = new Exchange();
                exchange.setId(rs.getInt("id"));
                exchange.setUserId(rs.getInt("user_id"));
                exchange.setOfferedBookId(rs.getInt("offered_book_id"));
                exchange.setRequestedBookId(rs.getInt("requested_book_id"));
                exchange.setExchangeType(rs.getString("exchange_type"));
                exchange.setStatus(rs.getString("status"));
                exchange.setRequestDate(rs.getTimestamp("request_date"));
                exchange.setApprovedBy(rs.getInt("approved_by"));
                exchange.setCompletionDate(rs.getString("completion_date"));
                exchanges.add(exchange);
            }
            return exchanges;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // Fix for V-003: checks the user actually has a current loan on the
    // offered book before allowing the exchange request.
    public boolean requestExchange(int userId, int offeredBookId, int requestedBookId) throws SQLException {
        Connection conn = null;
        PreparedStatement verifyOwnership = null;
        PreparedStatement insert = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();

            // verify the user actually has an active loan on the book they're offering
            verifyOwnership = conn.prepareStatement(
                "SELECT COUNT(*) FROM loans WHERE user_id = ? AND book_id = ? AND status = 'APPROVED'");
            verifyOwnership.setInt(1, userId);
            verifyOwnership.setInt(2, offeredBookId);
            rs = verifyOwnership.executeQuery();
            if (!rs.next() || rs.getInt(1) == 0) {
                return false; // user doesn't have this book on loan
            }

            String sql = "INSERT INTO exchanges (user_id, offered_book_id, requested_book_id, status) "
                       + "VALUES (?, ?, ?, 'PENDING')";
            insert = conn.prepareStatement(sql);
            insert.setInt(1, userId);
            insert.setInt(2, offeredBookId);
            insert.setInt(3, requestedBookId);
            boolean ok = insert.executeUpdate() > 0;
            if (ok) {
                AuditLogger.log(userId, "EXCHANGE_REQUESTED",
                    "Exchange: offered book " + offeredBookId + " for book " + requestedBookId);
            }
            return ok;
        } finally {
            DBConnection.close(null, verifyOwnership, rs);
            DBConnection.close(conn, insert, null);
        }
    }

    // Fixed: role check on exchange approval
    public boolean approveExchange(int exchangeId, int approverId, String approverRole) throws SQLException {
        if (!"LIBRARIAN".equals(approverRole) && !"ADMIN".equals(approverRole)) {
            throw new SecurityException("Only librarians or admins can approve exchanges");
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "UPDATE exchanges SET approved_by = ?, status = 'APPROVED' WHERE id = ? AND status = 'PENDING'");
            stmt.setInt(1, approverId);
            stmt.setInt(2, exchangeId);
            boolean ok = stmt.executeUpdate() > 0;
            if (ok) {
                AuditLogger.log(approverId, "EXCHANGE_APPROVED", "Approved exchange " + exchangeId);
            }
            return ok;
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }

    public boolean rejectExchange(int exchangeId, int approverId, String approverRole) throws SQLException {
        if (!"LIBRARIAN".equals(approverRole) && !"ADMIN".equals(approverRole)) {
            throw new SecurityException("Only librarians or admins can reject exchanges");
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "UPDATE exchanges SET approved_by = ?, status = 'REJECTED' WHERE id = ? AND status = 'PENDING'");
            stmt.setInt(1, approverId);
            stmt.setInt(2, exchangeId);
            boolean ok = stmt.executeUpdate() > 0;
            if (ok) {
                AuditLogger.log(approverId, "EXCHANGE_REJECTED", "Rejected exchange " + exchangeId);
            }
            return ok;
        } finally {
            DBConnection.close(conn, stmt, null);
        }
    }

    // ==================== ORDERS ====================
    public List<Order> getUserOrders(int userId) throws SQLException {
        List<Order> orders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Order order = new Order();
                order.setId(rs.getInt("id"));
                order.setUserId(rs.getInt("user_id"));
                order.setOrderDate(rs.getTimestamp("order_date"));
                order.setTotalAmount(rs.getBigDecimal("total_amount"));
                order.setStatus(rs.getString("status"));
                orders.add(order);
            }
            return orders;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // ==================== COLLECTIONS ====================

    // Fix for V-004: only researchers and admins can see restricted books,
    // and books with a future embargo date are filtered out.
    public List<Book> getRestrictedBooks(String callerRole) throws SQLException {
        if (!"RESEARCHER".equals(callerRole) && !"ADMIN".equals(callerRole)) {
            throw new SecurityException("Only researchers and admins can access restricted books");
        }

        List<Book> books = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            // only return restricted books whose embargo has passed (or never had one)
            stmt = conn.prepareStatement(
                "SELECT b.* FROM books b " +
                "JOIN collections c ON b.collection_id = c.id " +
                "WHERE c.is_restricted = TRUE " +
                "AND (b.embargo_date IS NULL OR b.embargo_date <= CURDATE())");
            rs = stmt.executeQuery();

            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setStock(rs.getInt("stock"));
                book.setEmbargoDate(rs.getString("embargo_date"));
                books.add(book);
            }
            return books;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }

    // ==================== AUDIT ====================

    // reads from the real audit_log table so the admin panel shows actual data
    public List<String[]> getAuditLog() throws SQLException {
        List<String[]> entries = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            stmt = conn.prepareStatement(
                "SELECT a.timestamp, u.username, a.action, a.details " +
                "FROM audit_log a LEFT JOIN users u ON a.user_id = u.id " +
                "ORDER BY a.timestamp DESC LIMIT 200");
            rs = stmt.executeQuery();

            while (rs.next()) {
                entries.add(new String[]{
                    rs.getString("timestamp"),
                    rs.getString("username") != null ? rs.getString("username") : "system",
                    rs.getString("action"),
                    rs.getString("details")
                });
            }
            return entries;
        } finally {
            DBConnection.close(conn, stmt, rs);
        }
    }
}
