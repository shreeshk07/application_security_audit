# Remediation Log — 03_Secured

Shreesh Kallihal (24261335)
Secure Application Development

This log covers every fix made in 03_Secured. It includes all ten pre-existing vulnerabilities that were already sitting in 01_Original and the five I injected into 02_Vulnerable. For each one I've written down the root cause anddthe actual fix I put in, which standard it maps to  and the SSDF practice it ties back to. Line numbers in this log refer to the 03_Secured source...

## Summary table

| ID       | Root cause                                     | Solution                                                         | Standard ref                              | SSDF  |
|----------|------------------------------------------------|------------------------------------------------------------------|-------------------------------------------|-------|
| ORIG-01  | Plaintext passwords in DB and WHERE clause     | BCrypt cost 12, char[] zeroing after hash                        | A02:2025 / CWE-256 / CERT MSC03-J         | PW.5  |
| ORIG-02  | No brute force protection on login             | 5-attempt counter and 30s lockout on LoginFrame                  | A07:2025 / CWE-307                        | PW.6  |
| ORIG-03  | No role checks on sensitive DAO methods        | callerRole parameter and SecurityException across 7 methods      | A01:2025 / CWE-284                        | PW.6  |
| ORIG-04  | Fallback guest login fabricates a User object  | Fallback removed, DB lookup is the only path into the app        | A07:2025 / CWE-287                        | PW.6  |
| ORIG-05  | Weak passwords accepted on registration        | InputValidator with length and complexity rule                   | A07:2025 / CWE-521                        | PW.1  |
| ORIG-06  | Stack trace and JDBC URL shown in error dialog | Generic message to the user, full trace to logger only           | A09:2025 / CWE-209                        | PO.2  |
| ORIG-07  | Empty catch blocks in DBConnection.close()     | Replaced with logger.warning, no silent swallowing               | CWE-390                                   | PO.2  |
| ORIG-08  | Hardcoded DB credentials in source             | Externalised to db.properties, loaded via Properties at startup  | A05:2025 / CWE-798                        | PO.3  |
| ORIG-09  | Fake audit log with hardcoded text             | Real audit_log table written by AuditLogger on sensitive actions | CWE-778                                   | PW.6  |
| ORIG-10  | No validation on stock and registration fields | InputValidator used at every DAO entry point                     | CWE-20                                    | PW.1  |
| V-001    | String concatenation in searchBooks()          | PreparedStatement with three bound LIKE patterns                 | A03:2025 / CWE-89                         | PW.5  |
| V-002    | No duplicate check on requestLoan()            | SELECT COUNT(*) before INSERT, duplicates rejected               | A06:2025 / CWE-840                        | PW.1  |
| V-003    | No ownership check on requestExchange()        | Ownership query against loans table before the INSERT            | A01:2025 / CWE-863                        | PW.1  |
| V-004    | No role or embargo filter on restricted list   | Role guard in the DAO + embargo_date <= CURDATE() in the SQL     | A01:2025 / CWE-862                        | PW.6  |
| V-005    | Login error echoes the username back           | Single generic message, no echo, no case distinction             | A09:2025 / CWE-209                        | PW.6  |

---

## ORIG-01 Plaintext Password Storage

Root cause: the original BookshopDAO.java at line 25 ran a SELECT that compared the password column directly, and new users were stored with their raw password in the users table. Anyone with a SELECT grant could read every password in the system.

Solution: BCrypt hashing via the jbcrypt 0.4 library with cost factor 12 which is the current minimum recommended by OWASP. The hash is generated in registerUser() at line 119 and verification lives in authenticateUser() at lines 46-47 via BCrypt.checkpw().

```java
// Storage (BookshopDAO.java:119)
stmt.setString(2, BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(12)));

// Verification (BookshopDAO.java:46-47)
String storedHash = rs.getString("password");
if (BCrypt.checkpw(password, storedHash)) { ... }
```

Java design linkage: Java strings are immutable so a password held as a String can sit in the heap until the GC decides to clean it up. The secured LoginFrame.java zeros the char[] at line 100 with `Arrays.fill(passwordChars, '\0')` the moment it's no longer needed, which is what CERT MSC03-J asks for.

Standard reference: OWASP A02:2025, CWE-256, CERT MSC03-J, SSDF PW.5.

---

## ORIG-02 No Brute Force Protection

Root cause: the original LoginFrame had no counter and no lockout, so an attacker could sit on the login form and try passwords for as long as they liked.

Solution: a 5-attempt counter with a 30-second cooldown added to LoginFrame.java. The counter variables are at lines 26-29, the lockout check happens at the top of performLogin() from lines 86-93, and the counter is bumped on failure at line 120 with the lockout set at line 122.

```java
// LoginFrame.java:26-29
private int failedAttempts = 0;
private long lockoutUntil = 0;
private static final int MAX_ATTEMPTS = 5;
private static final long LOCKOUT_MS = 30_000;
```

Standard reference: OWASP A07:2025, CWE-307, SSDF PW.6.

---

## ORIG-03 Missing Role Checks on DAO

Root cause: seven sensitive DAO methods (user admin, loan approvals, restricted list, audit read) had no authorisation check. Once any panel had a DAO handle it could call anything regardless of the caller's role.

Solution: every sensitive method now takes a `callerRole` argument and throws `SecurityException` when the role doesn't match the allowlist. The pattern is the same in every method so the rule is easy to spot in review. Example from getRestrictedBooks() at line 596:

```java
if (!"RESEARCHER".equals(callerRole) && !"ADMIN".equals(callerRole)) {
    throw new SecurityException("Access denied");
}
```

Because the check is in the DAO, the enforcement holds no matter which GUI panel called the method, and the checked exception forces the caller to deal with it.

Standard reference: OWASP A01:2025, CWE-284, SSDF PW.6.

---

## ORIG-04 Guest Fallback Fabrication

Root cause: if the DB lookup for the guest account failed, the original code built a User object in memory with role GUEST and called openMainFrame() on it. That was an authentication bypass ..you got into the app without any row ever existing in the users table.

Solution: the fallback block was deleted. In the secured LoginFrame the guest button still exists, but if the DB lookup returns null the flow ends with a plain "guest account unavailable" message and no fabricated User is created. No path into the app without a real users row.

Standard reference: OWASP A07:2025, CWE-287, SSDF PW.6 (fail-fast principle).

---

## ORIG-05 Weak Passwords on Registration

Root cause: the original addUser() accepted any string as a password, including one-character values and common dictionary entries.

Solution: a utility class `sad.util.InputValidator` was added. registerUser() now calls `InputValidator.validatePassword()` which enforces a minimum length of 8, at least one letter and one digit, and rejects the handful of common weak passwords. Because it's a utility class all the rules live in one place, so the policy can be tightened later without hunting through the DAO.

Standard reference: OWASP A07:2025, CWE-521, SSDF PW.1.

---

## ORIG-06 Stack Trace and JDBC URL in Error Dialog

Root cause: the original login catch block called `ex.printStackTrace()` and then showed `"Database error: " + ex.getMessage()` inside a JOptionPane. The JDBC URL, driver name, Java version and OS end up on the attacker's screen.

Solution: the catch block now writes the full exception to a `java.util.logging.Logger` at SEVERE level and shows the user a single generic message ("An error occurred, please try again later"). The detail stays on the server side where it can help the developer without handing a map to an attacker.

Standard reference: OWASP A09:2025, CWE-209, SSDF PO.2.

---

## ORIG-07 Empty Catch Blocks in DBConnection.close()

Root cause: the original DBConnection.close() swallowed every exception into `catch (Exception e) {}` across three statements. Any close failure went straight to the bin with no signal at all.

Solution: each catch now calls `LOG.log(Level.WARNING, ...)` with the exception so that leaks and driver-level failures actually show up somewhere you can find them. No exception is hidden.

Standard reference: CWE-390, SSDF PO.2.

---

## ORIG-08 Hardcoded Database Credentials

Root cause: DBConnection.java had the JDBC URL, username and password written directly into the source as `static final String` constants. Anyone decompiling the JAR or reading the repo sees them.

Solution: the three values were moved into `src/main/resources/db.properties` and the class now loads them once via `Class.getResourceAsStream("db.properties")` in a static initialiser. The `.properties` file is what gets replaced per environment, and the source carries no secrets. A safe fallback is logged and applied if the file can't be read, so the app still comes up in a misconfigured dev setup.

Standard reference: OWASP A05:2025, CWE-798, SSDF PO.3.

---

## ORIG-09 Fake Hardcoded Audit Log

Root cause: the admin panel at AdminPanel.java lines 196-206 had a string literal with fabricated log entries ("2026-02-15 10:30: Admin login" etc.) and the refresh button just redisplayed the same literal. Nothing was ever recorded.

Solution: a real `audit_log` table was added to the schema and a utility class `sad.util.AuditLogger` writes to it on every sensitive action (login success/fail, loan request, exchange request, user admin). The admin panel now runs a SELECT against that table and shows real rows with user_id, action, ip_address and details.

```java
// AuditLogger.java
"INSERT INTO audit_log (user_id, action, ip_address, details) VALUES (?, ?, ?, ?)"
```

Standard reference: CWE-778, SSDF PW.6.

---

## ORIG-10 Missing Input Validation on Stock and Password

Root cause: the book form accepted negative stock values and the registration form accepted any password. No central validation.

Solution: `InputValidator` is now called from every DAO entry point — `validateStock()` rejects negatives and non-numeric input, `validatePassword()` applies the ORIG-05 rule, and `validateEmail()` applies a basic format check. Because the rules are in a utility class they don't drift between callers.

Standard reference: CWE-20, SSDF PW.1.

---

## V-001 SQL Injection in searchBooks

Root cause: the vulnerable searchBooks() concatenated the keyword straight into the SQL string.

Solution: replaced the Statement with a PreparedStatement in BookshopDAO.java at line 206. There are three bound LIKE patterns so title, author and isbn all go through the driver as data rather than being interpolated into the SQL. The injection stops working because the driver treats the whole payload as a single literal.

```java
// BookshopDAO.java:206
String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?";
try (PreparedStatement ps = conn.prepareStatement(sql)) {
    String pattern = "%" + keyword + "%";
    ps.setString(1, pattern);
    ps.setString(2, pattern);
    ps.setString(3, pattern);
    ...
}
```

Standard reference: OWASP A03:2025, CWE-89, SSDF PW.5.

---

## V-002 Duplicate Loan Fix

Root cause: no duplicate check before the INSERT in requestLoan().

Solution: a SELECT COUNT(*) runs at BookshopDAO.java line 370 before the INSERT. If the same user already has a PENDING or APPROVED loan for the same book, the method returns false with a clear "loan already exists" message and the INSERT is skipped.

```java
// BookshopDAO.java:370
"SELECT COUNT(*) FROM loans WHERE user_id = ? AND book_id = ? "
 + "AND status IN ('PENDING','APPROVED')"
```

Standard reference: OWASP A06:2025, CWE-840, SSDF PW.1.

---

## V-003 Exchange Ownership Fix

Root cause: requestExchange() trusted the offered book_id without any check.

Solution: BookshopDAO.java at line 487 now runs a COUNT(*) on the loans table to confirm the caller actually has an APPROVED loan for the book they're offering. If the count is zero the exchange is rejected and nothing is written.

```java
// BookshopDAO.java:487
"SELECT COUNT(*) FROM loans WHERE user_id = ? AND book_id = ? "
 + "AND status = 'APPROVED'"
```

Standard reference: OWASP A01:2025, CWE-863, SSDF PW.1.

---

## V-004 Restricted Collection Fix

Root cause: no role check and no embargo filter on getRestrictedBooks().

Solution: the method now takes a `callerRole` argument. At line 596 it throws SecurityException if the role is not RESEARCHER or ADMIN. The SQL itself at line 612 adds `AND (b.embargo_date IS NULL OR b.embargo_date <= CURDATE())` so future-embargoed research is filtered by the database even if the role check ever gets bypassed. Defence in depth.

```java
// BookshopDAO.java:596
if (!"RESEARCHER".equals(callerRole) && !"ADMIN".equals(callerRole)) {
    throw new SecurityException("Access denied");
}
// BookshopDAO.java:612
"AND (b.embargo_date IS NULL OR b.embargo_date <= CURDATE())"
```

Standard reference: OWASP A01:2025, CWE-862, SSDF PW.6.

---

## V-005 Username Enumeration Fix

Root cause: login error echoed the attempted username and distinguished between wrong-username and wrong-password.

Solution: the dialog now shows a single generic "Invalid username or password" message with no echo and no case distinction. The attacker can't tell from the message whether the username even exists.

```java
JOptionPane.showMessageDialog(this,
    "Invalid username or password",
    "Login Failed", JOptionPane.ERROR_MESSAGE);
```

Standard reference: OWASP A09:2025, CWE-209, SSDF PW.6.
